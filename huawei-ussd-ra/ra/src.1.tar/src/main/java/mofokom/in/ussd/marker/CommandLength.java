        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The CommandLength field indicates the number of bytes of a USSD service application service protocol message.
* CommandLength comprises two parts: message header and message body, inclusive of the length of the CommandLength field.
* 
        *
        **/
        @Generated(value={})
        public interface CommandLength {
        }
