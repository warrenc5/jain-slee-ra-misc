        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The Password field indicates the password the USSD service application uses to log in to the USSDC.
* This field is used for the USSDC to authenticate the USSD service application.
*
        *
        **/
        @Generated(value={})
        public interface Password {
        }
