/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mofokom.in.ussd.resource.impl;

import java.io.IOException;
import java.io.Serializable;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.slee.Address;
import javax.slee.AddressPlan;
import javax.slee.EventTypeID;
import javax.slee.SLEEException;
import javax.slee.UnrecognizedEventException;
import javax.slee.facilities.FacilityException;
import javax.slee.facilities.Tracer;
import javax.slee.resource.ActivityFlags;
import javax.slee.resource.ActivityHandle;
import javax.slee.resource.ActivityIsEndingException;
import javax.slee.resource.EventFlags;
import javax.slee.resource.FireEventException;
import javax.slee.resource.FireableEventType;
import javax.slee.resource.IllegalEventException;
import javax.slee.resource.UnrecognizedActivityHandleException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import mofokom.in.ussd.CommandID;
import mofokom.in.ussd.UssdAbort;
import mofokom.in.ussd.UssdBegin;
import mofokom.in.ussd.UssdBind;
import mofokom.in.ussd.UssdBindResp;
import mofokom.in.ussd.resource.UssdActivity;
import mofokom.in.ussd.resource.UssdResourceAdaptorSBBInterface;
import mofokom.in.ussd.UssdCommand;
import mofokom.in.ussd.UssdEnd;
import mofokom.in.ussd.UssdShake;
import mofokom.in.ussd.UssdUnBind;
import mofokom.in.ussd.impl.UssdBindImpl;
import mofokom.in.ussd.impl.UssdCommandImpl;
import mofokom.in.ussd.impl.UssdConnectionListener;
import mofokom.in.ussd.impl.util.UssdConnection;
import mofokom.in.ussd.resource.MessageFactory;
import mofokom.in.ussd.resource.UssdResourceAdaptorUsageParameters;
import mofokom.resource.common.AbstractResourceAdaptor;
import mofokom.resource.common.TransactionException;
import mofokom.resource.common.TransactionHandle;
import static mofokom.in.ussd.resource.impl.UssdResourceAdaptor.UssdState.*;

/**
 *
 * @author wozza
 */
public class UssdResourceAdaptor extends AbstractResourceAdaptor<UssdActivityImpl, Serializable, UssdResourceAdaptorUsageParameters> implements UssdResourceAdaptorSBBInterface, UssdConnectionListener {

    private MessageFactory messageFactory;
    private Map<Integer, TransactionHandle> serverMap;
    private UssdConnection connection;
    private int activityFlags = ActivityFlags.REQUEST_ENDED_CALLBACK;
    private int eventFlags = EventFlags.REQUEST_PROCESSING_SUCCESSFUL_CALLBACK
            & EventFlags.REQUEST_PROCESSING_FAILED_CALLBACK;
    private long activityTimeout;
    private EventTypeID transportErrorEventID = new EventTypeID("TransportError", "MOFOKOM", "1.1");
    private EventTypeID timeoutEventID = new EventTypeID("TimeoutError", "MOFOKOM", "1.1");
    private ErrorCodes errorCodes;
    private long bindTimeout;
    private Long shakeTimeout;
    private ThreadPoolExecutor executor;
    private ShakeTask shakeTask;
    private UssdState ussdState;
    private UssdShake clonedShake;
    private UssdBind clonedBind;

    public void connected(UssdConnection connection) {
        tracer.info("connected");
        ussdState = CONNECTED;
        sendBind();
    }

    public void exception(UssdConnection connection, Exception ex) {
        tracer.severe(ex.getMessage(), ex);
    }

    public void disconnected(UssdConnection connection) {
        tracer.info("disconnected");
        ussdState = DISCONNECTED;
        super.raContext.getTimer().cancel();
    }

    public void received(UssdCommand cmd) {
        tracer.info(">" + cmd.toString());
        if (cmd.getCommandStatus() != 0)
            tracer.warning("error: " + cmd.getCommandStatus() + " " + errorForCommandStatus(cmd.getCommandStatus()));

        if (cmd.getCommandID() == CommandID.UssdShakeResp.intValue())
            ussdState = SHAKING;
        else if (cmd.getCommandID() == CommandID.UssdBindResp.intValue()) {
            //bound //pause q?
            if (cmd.getCommandStatus() != 0) {
                tracer.warning("non zero response - disconnecting");
                ussdState = ERROR;
                try {
                    connection.end();
                } catch (IOException ex) {
                    tracer.severe(ex.getMessage(), ex);
                } finally {
                    ussdState = DISCONNECTED;
                    return;
                }
            } else {
                ussdState = BOUND;
                tracer.info("bound");
            }

            if (ussdState == BOUND) //TODO use thread alive here
                startShaking();

        } else if (cmd.getCommandID() == CommandID.UssdUnBindResp.intValue())
            try {
                connection.end();
            } catch (IOException ex) {
                tracer.severe(ex.getMessage(), ex);
            }
        else {
            @SuppressWarnings("static-access")
            EventTypeID ID = ((UssdCommandImpl) cmd).getEventID();

            TransactionHandle handle = null;

            if (cmd.getCommandID() != CommandID.UssdBegin.intValue())
                handle = serverMap.get(cmd.getSenderCB());

            if (handle == null) {
                UssdActivityImpl activity = activityMap.get(Integer.valueOf(cmd.getReceiverCB()));
                if (activity != null)
                    handle = activity.getActivityHandle();
            }

            try {

                super.beginTransaction();

                if (cmd.getCommandID() == CommandID.UssdBegin.intValue()) {
                    int raId = this.hashCode();

                    UssdActivityImpl activity = createActivity(cmd);
                    super.startNewActivityTransacted(activity);
                    handle = activity.getActivityHandle();
                    activityMap.put(handle, activity);
                    serverMap.put(cmd.getSenderCB(), handle);
                }
                if (handle == null) {
                    tracer.info("handle not found");
                    return;
                }

                //TODO performance maybe only do this uni directional
                UssdActivityImpl activity = (UssdActivityImpl) activityMap.get(handle);
                //activity.cancel();
                //timer.schedule(activity, activityTimeout);
                Address address = null;
                if (cmd instanceof UssdBegin)
                    address = new Address(AddressPlan.E164, ((UssdBegin) cmd).getServiceCode());

                //TODO look this up in init
                FireableEventType eventType = super.raContext.getEventLookupFacility().getFireableEventType(ID);
                tracer.info("firing event " + eventType.getEventType().toString());
                super.raContext.getSleeEndpoint().fireEvent(handle, eventType, cmd, address, null, eventFlags);

                if (cmd instanceof UssdEnd || cmd instanceof UssdAbort || cmd instanceof UssdBindResp) {
                    super.endActivity(handle);
                    this.serverMap.remove(cmd.getSenderCB());
                }

                super.commitTransaction();
            } catch (NotSupportedException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (SystemException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (RollbackException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (HeuristicMixedException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (HeuristicRollbackException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (UnrecognizedActivityHandleException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (IllegalEventException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (ActivityIsEndingException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (FireEventException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (NullPointerException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (UnrecognizedEventException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (FacilityException ex) {
                tracer.severe(ex.getMessage(), ex);
            } catch (SLEEException ex) {
                tracer.severe(ex.getMessage(), ex);
            }


        }
    }

    private void fireFailureEvent(UssdCommand command, Exception x) {
        tracer.severe(x.getMessage(), x);
        throw new UnsupportedOperationException("Not yet implemented", x);
    }

    void fireTimeoutEvent(TransactionHandle handle) {
        try {
            FireableEventType eventType = super.raContext.getEventLookupFacility().getFireableEventType(timeoutEventID);
            tracer.info("firing event " + eventType.toString());
            UssdActivityImpl activity = activityMap.get(handle);
            UssdCommand command = activity.getAttachment();
            super.raContext.getSleeEndpoint().fireEvent(handle, eventType, command, null, null, eventFlags);
        } catch (UnrecognizedActivityHandleException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (IllegalEventException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (ActivityIsEndingException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (FireEventException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (FacilityException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (SLEEException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (NullPointerException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (UnrecognizedEventException ex) {
            tracer.severe(ex.getMessage(), ex);
        }

    }

    public MessageFactory getMessageFactory() {
        return messageFactory;
    }

    @Override
    public void activityTimeout(UssdActivityImpl txn) {
        if (tracer.isWarningEnabled())
            tracer.warning("Transaction id: " + txn.getActivityHandle().hashCode() + " timeout, firing timeout event");
        this.fireTimeoutEvent(txn.getActivityHandle());
        ;
        super.activityTimeout(txn);
    }

    public UssdActivity send(UssdCommand command) {
        return send((ActivityHandle) null, command);
    }

    public void send(UssdActivity activity, UssdCommand command) {
        send(((UssdActivityImpl) activity).getActivityHandle(), command);
    }

    public UssdActivity send(ActivityHandle activityHandle, UssdCommand command) {
        int raId = this.hashCode();
        UssdActivityImpl activity = null;


        if (!(command instanceof UssdBind || command instanceof UssdShake)) {
            if (activityHandle != null)
                activity = activityMap.get(activityHandle);

            if (activityHandle == null && command.getSenderCB() != -1) {
                activityHandle = serverMap.get(command.getSenderCB());
                if (activityHandle != null)
                    activity = activityMap.get(activityHandle);
            }

            if (activity == null) {
                activity = createActivity(command);
                super.startNewActivitySuspended(activity);
                activityMap.put(activity.getActivityHandle(), activity);
                serverMap.put(command.getReceiverCB(), activity.getActivityHandle());
            } else {
                command.setSenderCB(activity.getSequence());
                command.setReceiverCB(activity.getAttachment().getSenderCB());
            }

        }

        if (command instanceof UssdBegin) {//FIXME
            command.setSenderCB(999);
            super.scheduleEndActivity(activity, null);
            //we could send abort on timeout
            //the center will send abort on timeout.
        }
        //command.setSenderCB(activity.getSequence());

        //TODO set senderCB and receiverCB

        internalSend(command);

        return activity;
    }

    private void internalSend(UssdCommand command) {
        CommandSender sender = new CommandSender(command);
        executor.execute(sender);
    }

       public String errorForCommandStatus(int statusCode) {
        return errorCodes.getErrorMessage(statusCode);
    }

    public void raActive() {
        super.raActive();
        //new mofokom.deadlock.Deadlock();
        tracer.info("Activating");
        serverMap = new HashMap<Integer, TransactionHandle>(
                (Integer) properties.getProperty("ACTIVITY_DIMENSION").getValue());
        messageFactory = new MessageFactoryImpl();

        activityTimeout = (Long) properties.getProperty("ACTIVITY_TIMEOUT").getValue();
        bindTimeout = (Long) properties.getProperty("BIND_TIMEOUT").getValue();
        shakeTimeout = (Long) properties.getProperty("SHAKE_TIMEOUT").getValue();

        errorCodes = new ErrorCodes();

        BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<Runnable>(
                (Integer) properties.getProperty("WORK_QUEUE").getValue());
        executor = new ThreadPoolExecutor(
                (Integer) properties.getProperty("POOL_SIZE").getValue(),
                (Integer) properties.getProperty("MAX_POOL_SIZE").getValue(),
                (Long) properties.getProperty("POOL_TIMEOUT").getValue(),
                TimeUnit.SECONDS, workQueue);
    }

    public void raStopping() {
        super.raStopping();
        this.shakeTask.cancel();
        if (ussdState == BOUND && this.messageFactory != null) { //remove the second condition
            UssdUnBind ussdUnBind = this.messageFactory.createUssdUnBind();
            this.send(ussdUnBind);
        }
        //FIXME:  can we do this on slee timer.
        //timer.purge();
    }

    @Override
    public UssdActivityImpl createActivity(Object command) {
        UssdActivityImpl activity = new UssdActivityImpl((UssdCommand) command, this.hashCode(), sequence.getNextSequenceNumber());
        super.scheduleEndActivity(activity, new Date(activityTimeout));
        return activity;
    }

    public void setTracer(Tracer tracer) {
        this.tracer = tracer;
    }

    private void sendBind() {
        if (clonedBind == null)
            clonedBind = this.messageFactory.createUssdBind();

        clonedBind.setAccountName(
                (String) properties.getProperty("ACCOUNT_NAME").getValue());
        clonedBind.setPassword(
                (String) properties.getProperty("PASSWORD").getValue());
        clonedBind.setInterfaceVersion(
                (Integer) properties.getProperty("VERSION").getValue());
        clonedBind.setSystemType(
                ((Integer) properties.getProperty("SYSTEM_TYPE").getValue()).toString());
        tracer.info("binding");
        this.send(clonedBind);
        tracer.info("sending bind");

        super.getTimer().schedule(new TimerTask() {

            //CONNECTION LIFE CYCLE PROCESSOR
            @Override
            public void run() {
                if (!bound) {
                    tracer.info("still not bound, retrying");
                    sendBind();
                }
            }
        }, bindTimeout);
    }

    private void connect() {
        try {
            tracer.info("connecting");
            this.connection = new UssdConnection(new InetSocketAddress((String) properties.getProperty("HOST").getValue(), (Integer) properties.getProperty("PORT").getValue()), this);
            this.connection.start((Boolean) properties.getProperty("TCP_NO_DELAY").getValue(),
                    (Integer) properties.getProperty("SOCKET_TIMEOUT").getValue(),
                    (Integer) properties.getProperty("SOCKET_BUFFER_SIZE").getValue(),
                    (Boolean) properties.getProperty("KEEP_ALIVE").getValue());
        } catch (IOException ex) {
            tracer.severe(ex.getMessage(), ex);
        }
    }

    private void startShaking() {
        if (clonedShake != null)
            clonedShake = messageFactory.createUssdShake();
        super.raContext.getTimer().scheduleAtFixedRate(shakeTask = new ShakeTask(clonedShake), shakeTimeout / 2, shakeTimeout);
    }

    @Override
    public void processTransactionFailure(TransactionException transactionException) {
    }

    @Override
    public Collection<EventTypeID> getEventTypeSet() throws UnrecognizedEventException {
        return new EventTypeID[] { UssdBindImpl;
    }

    @Override
    public Object getResourceAdaptorInterface(String className) {
        return this;
    }

 private void waitForState(UssdState state) {

        switch (ussdState) {
            case DISCONNECTED:
                connect();
            case UNBOUND:
                sendBind();

        }

         //TODO use a q?
        //tracer.info("" + command.getClass().getName());
        if (!(command instanceof UssdBind)) {
            if (!bound)
                tracer.info("waiting for binding");

            if (connected)
                while (!bound) {
                    try {
                        Thread.sleep(200L);
                    } catch (InterruptedException ex) {
                    }
                }
        }

    }


    class ShakeTask extends TimerTask {

        private final UssdShake shake;

        public ShakeTask(UssdShake shake) {
            this.shake = shake;
        }

        @Override
        public void run() {
            if (!connected) {
                tracer.info("not connected, connecting");
                this.cancel();
            }

            if (shaking) {
                tracer.info("already shaking, ending");
                try {
                    connection.end();
                } catch (IOException ex) {
                    tracer.severe(ex.getMessage(), ex);
                }

                UssdResourceAdaptor.this.connect();
                shaking = false;
            }

            shaking = true;

            UssdResourceAdaptor.this.send(shake);
            /*
            } catch (IOException ex) {
            connected = false;
            bound = false;
            tracer.severe(ex.getMessage(),ex);
            }*/
        }
    }

    private class CommandSender implements Runnable {

        UssdCommand command;

        public CommandSender(UssdCommand command) {
            this.command = command;
        }

        @SuppressWarnings("element-type-mismatch")
        public void run() {

            try {
                connection.send(command);
                tracer.info("sent");
            } catch (Exception x) {
                ussdState = ERROR;
                fireFailureEvent(command, x);
            }
        }
    }

    public enum UssdState {

        DISCONNECTED, CONNECTED, BOUND, SHAKING, UNBOUND, ERROR;
    };
}
