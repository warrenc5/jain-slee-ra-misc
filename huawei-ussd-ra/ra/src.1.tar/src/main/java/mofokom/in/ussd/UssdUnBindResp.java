        package mofokom.in.ussd;
        import javax.annotation.Generated;
        /**
        *
        * The following table defines the syntax of UssdUnBindResp.
*
        *
        **/
        @Generated(value={})
        public interface UssdUnBindResp extends UssdCommand {
        }
