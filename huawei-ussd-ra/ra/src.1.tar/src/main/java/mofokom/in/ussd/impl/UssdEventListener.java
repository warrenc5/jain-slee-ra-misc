/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mofokom.in.ussd.impl;

import mofokom.in.ussd.UssdCommand;
import mofokom.in.ussd.impl.util.UssdConnection;

/**
 *
 * @author wozza
 */
public interface UssdEventListener extends java.util.EventListener {

    void received(UssdCommand cmd);

}
