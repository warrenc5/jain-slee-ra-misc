        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The ReceiverCB field indicates the session control identifier of the receiver.
* During a USSD session, ReceiverCB is used for the receiver to identify the current session.
* If a message does not use the field, set the field to 0xFFFFFFFF.
*
        *
        **/
        @Generated(value={})
        public interface ReceiverCB {
        }
