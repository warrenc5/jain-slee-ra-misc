        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The ChargeRatio field indicates the charging ratio of the charging indication.
* Its unit is fen (0.
*01 yuan).
* The value 0 means free of charge.
* 
        *
        **/
        @Generated(value={})
        public interface ChargeRatio {
        }
