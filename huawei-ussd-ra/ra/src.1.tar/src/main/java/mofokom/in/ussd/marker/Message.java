        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * 
        *
        **/
        @Generated(value={})
        public interface Message {
        }
