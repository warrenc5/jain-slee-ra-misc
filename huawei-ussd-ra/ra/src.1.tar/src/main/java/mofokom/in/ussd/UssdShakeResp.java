        package mofokom.in.ussd;
        import javax.annotation.Generated;
        /**
        *
        * The following table defines the syntax of the USSDShakeResp message.
*
        *
        **/
        @Generated(value={})
        public interface UssdShakeResp extends UssdCommand {
        }
