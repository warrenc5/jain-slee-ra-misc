        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The MsIsdn field indicates the number of the mobile station in a session.
*
        *
        **/
        @Generated(value={})
        public interface MsIsdn {
        }
