        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The InterfaceVersion field indicates the version of the USSD service application protocol.
* The current version is 0x10.
*
        *
        **/
        @Generated(value={})
        public interface InterfaceVersion {
        }
