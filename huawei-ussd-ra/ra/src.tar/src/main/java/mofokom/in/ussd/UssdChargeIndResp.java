        package mofokom.in.ussd;
        import javax.annotation.Generated;
        /**
        *
        * UssdChargeIndResp is used for the USSDC to notify the USSD service application of the results of processing the charging indication message.
*
The following table defines the syntax of UssdChargeIndResp.
*
        *
        **/
        @Generated(value={})
        public interface UssdChargeIndResp extends UssdCommand {
        }
