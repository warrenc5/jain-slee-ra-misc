        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The CommandStatus field indicates the status of a successful or faulty USSD service application protocol message.
* If a message does not use the CommandStatus field, set the field to NULL.
*
        *
        **/
        @Generated(value={})
        public interface CommandStatus {
        }
