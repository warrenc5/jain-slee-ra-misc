        package mofokom.in.ussd;
        import javax.annotation.Generated;
        /**
        *
        * UssdAbort can be sent either by a mobile station or by the USSD service application to abort a USSD session with the USSDC.
* UssdAbort indicates that a USSD session ends abnormally.
*
The following table defines the syntax of UssdAbort.
*
        *
        **/
        @Generated(value={})
        public interface UssdAbort extends UssdCommand {
        }
