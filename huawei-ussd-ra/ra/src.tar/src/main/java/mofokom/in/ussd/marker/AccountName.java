        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The AccountName field indicates the account name of the USSD service application which is to log in to the USSDC.
*
        *
        **/
        @Generated(value={})
        public interface AccountName {
        }
