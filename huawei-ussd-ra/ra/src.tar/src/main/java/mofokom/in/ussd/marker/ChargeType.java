        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The ChargeType field indicates the charging types of the charging indication.
* Currently, this field includes the following charging types:0: free, 1: per message, 2: per monthly flat rate, and 3: per monthly flat rate for downlink.
*
        *
        **/
        @Generated(value={})
        public interface ChargeType {
        }
