        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The ChargeLocation field indicates the location where bills are generated.
* There are the following three cases: 1: Both the USSDC and the USSD service platform generate bills.
* 2: Only the USSDC generates bills.
* 3: Only the USSD service platform generates bills.
*
        *
        **/
        @Generated(value={})
        public interface ChargeLocation {
        }
