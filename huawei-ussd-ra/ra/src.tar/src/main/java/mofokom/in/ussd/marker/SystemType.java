        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The SystemType field indicates the type of the USSD service application.
* At present, this field is not ready for use yet.
*
        *
        **/
        @Generated(value={})
        public interface SystemType {
        }
