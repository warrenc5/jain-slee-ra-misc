/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mofokom.in.ussd.resource;

import mofokom.in.ussd.UssdCommand;

/**
 *
 * @author wozza
 */
public interface UssdResourceAdaptorSBBInterface {

    MessageFactory getMessageFactory();
    UssdActivity send(UssdCommand command);
    void send(UssdActivity activity,UssdCommand command);
    String errorForCommandStatus(int statusCode);

}
