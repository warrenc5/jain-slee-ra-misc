package mofokom.in.ussd.event;

public class TimeoutError  {
    public TimeoutError() {
    }
}
