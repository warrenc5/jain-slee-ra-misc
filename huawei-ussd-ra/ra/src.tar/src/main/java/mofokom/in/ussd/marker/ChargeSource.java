        package mofokom.in.ussd.marker;
        import javax.annotation.Generated;
        /**
        *
        * The ChargeSource field indicates the identifier of the charging source.
* The service party interprets the specific implication of the contents of this field.
* 
        *
        **/
        @Generated(value={})
        public interface ChargeSource {
        }
