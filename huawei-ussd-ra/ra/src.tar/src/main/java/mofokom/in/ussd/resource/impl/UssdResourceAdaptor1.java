/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mofokom.in.ussd.resource.impl;

import mofokom.in.ussd.impl.util.Util;
import java.util.Arrays;
import mofokom.in.ussd.impl.UssdAbortImpl;
import mofokom.in.ussd.impl.UssdBeginImpl;
import mofokom.in.ussd.impl.UssdBindRespImpl;
import mofokom.in.ussd.impl.UssdChargeIndImpl;
import mofokom.in.ussd.impl.UssdChargeIndRespImpl;
import mofokom.in.ussd.impl.UssdContinueImpl;
import mofokom.in.ussd.impl.UssdEndImpl;
import mofokom.in.ussd.impl.UssdShakeImpl;
import mofokom.in.ussd.impl.UssdShakeRespImpl;
import mofokom.in.ussd.impl.UssdSwitchImpl;
import mofokom.in.ussd.impl.UssdUnBindImpl;
import mofokom.in.ussd.impl.UssdUnBindRespImpl;
import java.io.IOException;
import java.io.Serializable;
import java.net.InetSocketAddress;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import javax.slee.Address;
import javax.slee.AddressPlan;
import javax.slee.EventTypeID;
import javax.slee.SLEEException;
import javax.slee.UnrecognizedEventException;
import javax.slee.facilities.FacilityException;
import javax.slee.facilities.Tracer;
import javax.slee.resource.ActivityFlags;
import javax.slee.resource.ActivityHandle;
import javax.slee.resource.ActivityIsEndingException;
import javax.slee.resource.EventFlags;
import javax.slee.resource.FireEventException;
import javax.slee.resource.FireableEventType;
import javax.slee.resource.IllegalEventException;
import javax.slee.resource.UnrecognizedActivityHandleException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import mofokom.in.ussd.CommandID;
import mofokom.in.ussd.UssdBegin;
import mofokom.in.ussd.UssdBind;
import mofokom.in.ussd.UssdBindResp;
import mofokom.in.ussd.resource.UssdActivity;
import mofokom.in.ussd.resource.UssdResourceAdaptorSBBInterface;
import mofokom.in.ussd.UssdCommand;
import mofokom.in.ussd.UssdShake;
import mofokom.in.ussd.UssdUnBind;
import mofokom.in.ussd.impl.UssdBindImpl;
import mofokom.in.ussd.impl.util.UssdConnectionListener;
import mofokom.in.ussd.impl.util.UssdConnection;
import mofokom.in.ussd.resource.MessageFactory;
import mofokom.in.ussd.resource.UssdResourceAdaptorUsageParameters;
import mofokom.resource.common.AbstractResourceAdaptor;
import mofokom.resource.common.TransactionException;
import mofokom.resource.common.TransactionHandle;
import static mofokom.in.ussd.resource.impl.UssdResourceAdaptor.UssdState.*;

/**
 *
 * @author wozza
 */
public class UssdResourceAdaptor extends AbstractResourceAdaptor<UssdActivityImpl, Serializable, UssdResourceAdaptorUsageParameters> implements UssdResourceAdaptorSBBInterface, UssdConnectionListener {

    private MessageFactory messageFactory;
    private Map<Integer, TransactionHandle> serverMap;
    private UssdConnection connection;
    private int activityFlags = ActivityFlags.REQUEST_ENDED_CALLBACK;
    private int eventFlags = EventFlags.REQUEST_PROCESSING_SUCCESSFUL_CALLBACK
            & EventFlags.REQUEST_PROCESSING_FAILED_CALLBACK;
    private long activityTimeout;
    private EventTypeID transportErrorEventID = new EventTypeID("TransportError", "MOFOKOM", "1.1");
    private EventTypeID timeoutEventID = new EventTypeID("TimeoutError", "MOFOKOM", "1.1");
    private ErrorCodes errorCodes;
    private long bindTimeout;
    private Long shakeTimeout;
    private ShakeSenderTask shakeTask;
    private UssdState ussdState;
    private UssdShake clonedShake;
    private UssdBind clonedBind;

    public void connected(UssdConnection connection) {
        tracer.info("connected");
        ussdState = CONNECTED;
        try {
            stateTransition();
        } catch (IOException ex) {
            tracer.severe(ex.getMessage(), ex);
        }
    }

    public void exception(UssdConnection connection, Exception ex) {
        tracer.severe(ex.getMessage(), ex);
    }

    public void disconnected(UssdConnection connection) {
        tracer.info("disconnected");
        ussdState = DISCONNECTED;
        super.raContext.getTimer().cancel();
    }

    public void received(UssdCommand cmd) {
        tracer.info(">" + cmd.toString());

        if (cmd.getCommandStatus() != 0)
            tracer.warning("error: " + cmd.getCommandStatus() + " " + errorForCommandStatus(cmd.getCommandStatus()));

        CommandID cmdId = CommandID.forInt(cmd.getCommandID());

        switch (cmdId) {
            case UssdAbort:
                break;
            case UssdBegin:
                break;
            case UssdBind:
                break;
            case UssdBindResp:
                processBindResponse((UssdBindResp) cmd);
                break;
            case UssdChargeInd:
                break;
            case UssdChargeIndResp:
                break;
            case UssdContinue:
                break;
            case UssdEnd:
                break;
            case UssdShake:
                break;
            case UssdShakeResp:
                ussdState = SHAKING;
                break;
            case UssdSwitch:
                break;
            case UssdUnBind:
                break;
            case UssdUnBindResp:
                try {
                    ussdState = UNBOUND;
                    prepareDisconnect();
                    connection.end();
                } catch (IOException ex) {
                    tracer.severe(ex.getMessage(), ex);
                }
                break;
            default:
        }

        TransactionHandle handle = null;

        try {

            if (cmdId != CommandID.UssdBegin)
                handle = serverMap.get(cmd.getSenderCB());

            if (handle == null) {
                UssdActivityImpl activity = activityMap.get(Integer.valueOf(cmd.getReceiverCB()));
                if (activity != null)
                    handle = activity.getActivityHandle();
            }

            final EventTypeID eventTypeID = Util.eventTypeIDForCommand(cmd);

            if (super.isEventSupressed(eventTypeID)) {
                tracer.info("event suppressed " + eventTypeID.toString());
                return;
            }

            super.beginTransaction();

            if (cmdId == CommandID.UssdBegin) {
                int raId = this.hashCode();
                UssdActivityImpl activity = createActivity(cmd);
                super.startNewActivityTransacted(activity);
                handle = activity.getActivityHandle();
                activityMap.put(handle, activity);
                serverMap.put(cmd.getSenderCB(), handle);
            }


            //TODO performance maybe only do this uni directional
            //activity = (UssdActivityImpl) activityMap.get(handle);
            //activity.cancel();
            //timer.schedule(activity, activityTimeout);

            if (handle == null) {
                tracer.info("handle not found");
                return;
            }

            Address address = null;
            if (cmd instanceof UssdBegin)
                address = new Address(AddressPlan.E164, ((UssdBegin) cmd).getServiceCode());

            //TODO look this up in init

            FireableEventType eventType = super.raContext.getEventLookupFacility().getFireableEventType(eventTypeID);
            tracer.info("firing event " + eventType.getEventType().toString());

            super.raContext.getSleeEndpoint().fireEvent(handle, eventType, cmd, address, null, eventFlags);

            switch (cmdId) {
                case UssdAbort:
                case UssdBindResp:
                case UssdEnd:
                    super.endActivity(handle);
            }

            super.commitTransaction();
        } catch (NotSupportedException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (SystemException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (RollbackException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (HeuristicMixedException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (HeuristicRollbackException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (UnrecognizedActivityHandleException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (IllegalEventException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (ActivityIsEndingException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (FireEventException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (NullPointerException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (UnrecognizedEventException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (FacilityException ex) {
            tracer.severe(ex.getMessage(), ex);
        } catch (SLEEException ex) {
            tracer.severe(ex.getMessage(), ex);
        }

    }

    void fireTimeoutEvent(TransactionHandle handle) {
        try {
            FireableEventType eventType = super.raContext.getEventLookupFacility().getFireableEventType(timeoutEventID);
            tracer.info("firing event " + eventType.toString());
            UssdActivityImpl activity = activityMap.get(handle);
            UssdCommand command = activity.getAttachment();
            super.raContext.getSleeEndpoint().fireEvent(handle, eventType, command, null, null, eventFlags);
            super.endActivity(activity);


        } catch (UnrecognizedActivityHandleException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (IllegalEventException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (ActivityIsEndingException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (FireEventException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (FacilityException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (SLEEException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (NullPointerException ex) {
            tracer.severe(ex.getMessage(), ex);


        } catch (UnrecognizedEventException ex) {
            tracer.severe(ex.getMessage(), ex);


        }

    }

    public MessageFactory getMessageFactory() {
        return messageFactory;


    }

    @Override
    public void activityTimeout(UssdActivityImpl txn) {
        if (tracer.isWarningEnabled())
            tracer.warning("Transaction id: " + txn.getActivityHandle().hashCode() + " timeout, firing timeout event");


        this.fireTimeoutEvent(txn.getActivityHandle());


        super.activityTimeout(txn);
    }

    public UssdActivity send(UssdCommand command) {
        return send((ActivityHandle) null, command);
    }

    public void send(UssdActivity activity, UssdCommand command) {
        send(((UssdActivityImpl) activity).getActivityHandle(), command);
    }

    public UssdActivity send(ActivityHandle activityHandle, UssdCommand command) {
        int raId = this.hashCode();
        UssdActivityImpl activity = null;

        if (!(command instanceof UssdBind || command instanceof UssdShake)) {
            if (activityHandle != null)
                activity = activityMap.get(activityHandle);

            if (activityHandle == null && command.getSenderCB() != -1) {
                activityHandle = serverMap.get(command.getSenderCB());


                if (activityHandle != null)
                    activity = activityMap.get(activityHandle);
            }

            if (activity == null) {
                activity = createActivity(command);

                super.startNewActivitySuspended(activity);
                activityMap.put(activity.getActivityHandle(), activity);
                serverMap.put(command.getReceiverCB(), activity.getActivityHandle());


            } else {
                command.setSenderCB(activity.getSequence());
                command.setReceiverCB(activity.getAttachment().getSenderCB());


            }

        }

        if (command instanceof UssdBegin) {//FIXME
            //command.setSenderCB(999);
            activity.getAttachment().setSenderCB(activity.getSequence());
            super.scheduleEndActivity(activity, new Date(activityTimeout));
            //we could send abort on timeout to the center on behalf of the service
            //the center will send abort on timeout.
        }
        //TODO set senderCB and receiverCB

        CommandSender sender = new CommandSender(activity);
        executor.execute(sender);
        return activity;
    }

    private void sendInternal(UssdCommand command) throws IOException {
        connection.send(command);
    }

    public String errorForCommandStatus(int statusCode) {
        return errorCodes.getErrorMessage(statusCode);
    }

    public void raActive() {
        super.raActive();
        //new mofokom.deadlock.Deadlock();
        tracer.info("Activating");
        serverMap = new HashMap<Integer, TransactionHandle>(
                (Integer) properties.getProperty("ACTIVITY_DIMENSION").getValue());
        messageFactory = new MessageFactoryImpl();

        activityTimeout = (Long) properties.getProperty("ACTIVITY_TIMEOUT").getValue();
        bindTimeout = (Long) properties.getProperty("BIND_TIMEOUT").getValue();
        shakeTimeout = (Long) properties.getProperty("SHAKE_TIMEOUT").getValue();

        errorCodes = new ErrorCodes();

        BlockingQueue<Runnable> workQueue = new ArrayBlockingQueue<Runnable>(
                (Integer) properties.getProperty("WORK_QUEUE").getValue());

    }

    public void raStopping() {
        super.raStopping();
        this.shakeTask.cancel();

        if (ussdState == BOUND && this.messageFactory != null) { //remove the second condition
            UssdUnBind ussdUnBind = this.messageFactory.createUssdUnBind();
            this.send(ussdUnBind);
        }
        //FIXME:  can we do this on slee timer.
        //timer.purge();
    }

    @Override
    public UssdActivityImpl createActivity(Object command) {
        UssdActivityImpl activity = new UssdActivityImpl((UssdCommand) command, this.hashCode(), sequence.getNextSequenceNumber());
        return activity;
    }

    public void setTracer(Tracer tracer) {
        this.tracer = tracer;
    }

    private void sendBind() throws IOException {
        if (clonedBind == null)
            clonedBind = this.messageFactory.createUssdBind();

        clonedBind.setAccountName(
                (String) properties.getProperty("ACCOUNT_NAME").getValue());
        clonedBind.setPassword(
                (String) properties.getProperty("PASSWORD").getValue());
        clonedBind.setInterfaceVersion(
                (Integer) properties.getProperty("VERSION").getValue());
        clonedBind.setSystemType(
                ((Integer) properties.getProperty("SYSTEM_TYPE").getValue()).toString());

        tracer.info("binding");

        this.sendInternal(clonedBind);
        tracer.info("sending bind");
    }

    private void connect() throws IOException {
        tracer.info("connecting");

        this.connection = new UssdConnection(new InetSocketAddress((String) properties.getProperty("HOST").getValue(), (Integer) properties.getProperty("PORT").getValue()), this);
        this.connection.start((Boolean) properties.getProperty("TCP_NO_DELAY").getValue(),
                (Integer) properties.getProperty("SOCKET_TIMEOUT").getValue(),
                (Integer) properties.getProperty("SOCKET_BUFFER_SIZE").getValue(),
                (Boolean) properties.getProperty("KEEP_ALIVE").getValue());
    }

    private void startShaking() {
        if (clonedShake != null)
            clonedShake = messageFactory.createUssdShake();

        super.raContext.getTimer().scheduleAtFixedRate(shakeTask = new ShakeSenderTask(), 0, shakeTimeout);
    }

    @Override
    public void processTransactionFailure(TransactionException transactionException) {
    }

    @Override
    public Collection<EventTypeID> getEventTypeSet() throws UnrecognizedEventException {
        return Arrays.asList(UssdAbortImpl.EVENT_TYPE_ID,
                UssdBeginImpl.EVENT_TYPE_ID,
                UssdBindImpl.EVENT_TYPE_ID,
                UssdBindRespImpl.EVENT_TYPE_ID,
                UssdChargeIndImpl.EVENT_TYPE_ID,
                UssdChargeIndRespImpl.EVENT_TYPE_ID,
                UssdContinueImpl.EVENT_TYPE_ID,
                UssdEndImpl.EVENT_TYPE_ID,
                UssdShakeImpl.EVENT_TYPE_ID,
                UssdShakeRespImpl.EVENT_TYPE_ID,
                UssdSwitchImpl.EVENT_TYPE_ID,
                UssdUnBindImpl.EVENT_TYPE_ID,
                UssdUnBindRespImpl.EVENT_TYPE_ID,
                this.timeoutEventID, this.transportErrorEventID);
    }

    @Override
    public Object getResourceAdaptorInterface(String className) {
        return this;
    }

    @Override
    public void activityEnded(ActivityHandle handle) {
        super.activityEnded(handle);
        this.serverMap.remove(((TransactionHandle) handle).getAttachment());
    }

    @Override
    public void activityUnreferenced(ActivityHandle handle) {
        super.activityUnreferenced(handle);
        this.serverMap.remove(((TransactionHandle) handle).getAttachment());
    }

    @Override
    public void administrativeRemove(ActivityHandle handle) {
        super.administrativeRemove(handle);
        this.serverMap.remove(((TransactionHandle) handle).getAttachment());
    }

    private void processBindResponse(UssdBindResp cmd) {
        if (cmd.getCommandStatus() != 0) {
            tracer.warning("non zero response - disconnecting");
            ussdState = ERROR;

            try {
                connection.end();
            } catch (IOException ex) {
                tracer.severe(ex.getMessage(), ex);
            } finally {
                ussdState = DISCONNECTED;
                return;
            }
        } else {
            ussdState = BOUND;
            tracer.info("bound");
            try {
                stateTransition();
            } catch (IOException ex) {
                tracer.severe(ex.getMessage(), ex);
            }
        }
    }

    private void prepareDisconnect() {
        shakeTask.cancel();
    }

    /*
    switch (ussdState) {
    case DISCONNECTED:
    connect();
    case UNBOUND:
    sendBind();
    
    }
    
    //TODO use a q?
    //tracer.info("" + activity.getClass().getName());
    if (!(activity instanceof UssdBind)) {
    if (!bound)
    tracer.info("waiting for binding");
    
    if (connected)
    while (!bound) {
    try {
    Thread.sleep(200L);
    } catch (InterruptedException ex) {
    }
    }
    }
    
    }
    
     * */
    class ShakeSenderTask extends TimerTask {

        @Override
        public void run() {
            try {
                UssdResourceAdaptor.this.sendInternal(clonedShake);
            } catch (IOException ex) {
                tracer.severe(ex.getMessage(), ex);
                ussdState = ERROR;
            }
        }
    }
    /*
    super.getTimer().schedule(new TimerTask() {
    //CONNECTION LIFE CYCLE PROCESSOR
    @Override
    public void run() {
    if (!bound) {
    tracer.info("still not bound, retrying");
    sendBind();
    }
    }
    }, bindTimeout);
    /*
    if (!) {
    tracer.info("not connected, connecting");
    this.cancel();
    }
    if (shaking) {
    tracer.info("already shaking, ending");
    try {
    connection.end();
    } catch (IOException ex) {
    tracer.severe(ex.getMessage(), ex);
    }
    UssdResourceAdaptor.this.connect();
    shaking = false;
    }
    shaking = true;
    UssdResourceAdaptor.this.send(shake);
     *
     */
    /*
    } catch (IOException ex) {
    connected = false;
    bound = false;
    tracer.severe(ex.getMessage(),ex);
    }*/

    private class CommandSender implements Runnable {

        UssdActivityImpl activity;

        public CommandSender(UssdActivityImpl command) {
            this.activity = command;
        }

        @SuppressWarnings("element-type-mismatch")
        public void run() {
            checkStateForSending();

            try {
                sendInternal(activity.getAttachment());
                tracer.info("sent");
            } catch (Exception x) {
                ussdState = ERROR;
                throw new TransactionException(activity, x);
            }
        }
    }

    private void checkStateForSending() {
        if (ussdState != BOUND || ussdState != SHAKING)
            throw new IllegalStateException("Can't send command in state " + ussdState.name());
    }

    private void stateTransition() throws IOException { // add old state parameter ?
        switch (ussdState) {
            case DISCONNECTED:
                connect();
            case CONNECTED:
                sendBind();
                break; //wait for shake timeout before sending shake??
            case BOUND:
            case SHAKING:
                startShaking();
        }
    }

    public enum UssdState {

        DISCONNECTED, CONNECTED, BOUND, SHAKING, UNBOUND, ERROR;
    };
}
