package javax.megaco.pkg.ext.ASRPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//The amount of silence necessary after the end of the speech, specified in units 
@Generated({"warren crossing"})
public class PostSpeechTimerParam extends PkgItemParam {
	public static final int POSTSPEECHTIMER = 0x000c;
	public static final String TOKEN = "pst";

	protected int[] paramsItemIds = null;

	public PostSpeechTimerParam() {
		super();
		super.paramId = POSTSPEECHTIMER; //pst
		super.itemValueType = ParamValueType.M_INTEGER; //M_INTEGER
		super.paramsDescriptorIds = new int[] {};
        super.packageId = ASRPkg.PACKAGE_INSTANCE;
 //0x00a6		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

