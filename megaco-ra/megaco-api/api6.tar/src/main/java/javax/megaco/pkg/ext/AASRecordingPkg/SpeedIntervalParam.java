package javax.megaco.pkg.ext.AASRecordingPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Indicates the percentage increase or decrease in speed when the speed up or 
@Generated({"warren crossing"})
public class SpeedIntervalParam extends PkgItemParam {
	public static final int SPEED_INTERVAL = 0x001a;
	public static final String TOKEN = "spdint";

	protected int[] paramsItemIds = null;

	public SpeedIntervalParam() {
		super();
		super.paramId = SPEED_INTERVAL; //spdint
		super.itemValueType = ParamValueType.M_INTEGER; //M_INTEGER
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AASRecordingPkg.PACKAGE_INSTANCE;
 //0x0035		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

