package javax.megaco.pkg.ext.AASRecordingPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Indicates which DTMF digits map to an external key operation. Its function on 
@Generated({"warren crossing"})
public class ExternalControlKeyParam extends PkgItemParam {
	public static final int EXTERNAL_CONTROL_KEY = 0x0022;
	public static final String TOKEN = "extkey";

	protected int[] paramsItemIds = null;

	public ExternalControlKeyParam() {
		super();
		super.paramId = EXTERNAL_CONTROL_KEY; //extkey
		super.itemValueType = ParamValueType.M_STRING; //M_STRING
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AASRecordingPkg.PACKAGE_INSTANCE;
 //0x0035		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

