package javax.megaco.message.descriptor;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * The TimeStamp object is a class that shall be used to set the time and date
 * at which the event was detected within the observed event descriptor. This is
 * an independent class derived from java.util.Object and shall not have any
 * derived classes.
 */
public class TimeStamp implements Serializable {

    private GregorianCalendar gc = new GregorianCalendar();

    /**
     * Constructs a timestamp object that contains the date and time. This shall
     * be used within the observed event to detect the time at which the event
     * was detected. Time stamp should be valid GregorianCallendar date.
     *
     * @param year -
     * @param month - index of month, starting from 0 for January
     * @param day - day of month
     * @param hour - 24h format hour
     * @param min -
     * @param sec -
     * @throws IllegalArgumentException - Thrown if an illegal date or time
     * parameter is set.
     */
    public TimeStamp(int year, int month, int day, int hour, int min, int sec) throws IllegalArgumentException {
        // Lets use trick to validate.

        gc.setLenient(false);

        gc.set(gc.YEAR, year);
        gc.set(gc.MONTH, month);
        gc.set(gc.DAY_OF_MONTH, day);
        gc.set(gc.HOUR_OF_DAY, hour);
        gc.set(gc.MINUTE, min);
        if (sec > 59) {
            gc.set(gc.SECOND, (sec / 100));
            int milli = sec - ((sec / 100)) * 100;
            System.out.println("a" + sec);
            gc.set(gc.MILLISECOND, milli);
        } else {
            gc.set(gc.SECOND, sec);
            gc.set(gc.MILLISECOND, 0);
        }


        // here we validate
        gc.getTime();

    }

    /**
     * The method is used the to retrieve the year from the absolute date set.
     *
     * @return year - The integer value of the year.
     */
    public int getYear() {
        return this.gc.get(gc.YEAR);
    }

    /**
     * The method can be used the to retrieve month set in the object.
     *
     * @return month - Integer value of the month.
     */
    public int getMonth() {
        return this.gc.get(gc.MONTH);
    }

    /**
     * The method can be used the to retrieve day set in the object.
     *
     * @return day - Integer value of the day.
     */
    public int getDay() {
        return this.gc.get(gc.DAY_OF_MONTH);
    }

    /**
     * The method is used the to retrieve the hour from the absolute time set.
     *
     * @return hour - The integer value of the hour.
     */
    public int getHour() {
        return this.gc.get(gc.HOUR_OF_DAY);
    }

    /**
     * The method is used the to retrieve the minutes from the absolute time
     * set.
     *
     * @return minutes - The integer value of the minutes.
     */
    public int getMinutes() {
        return this.gc.get(gc.MINUTE);
    }

    /**
     * The method is used the to retrieve the secs from the absolute time set.
     *
     * @return secs - The integer value of the secs.
     */
    public int getSecs() {
        return this.gc.get(gc.SECOND);
    }

    transient DateFormat f = new SimpleDateFormat("yyyyMMdd'T'HHmmssSS");

    /**
     * 
     * @return
     */
    public String toStringEncode() {
        return f.format(gc.getTime());
    }





public String toString() {
 StringBuilder bob = new StringBuilder();
bob.append("TimeStamp:");

if(gc !=null)
bob.append("gc=").append(gc).append(",");
if(f !=null)
bob.append("f=").append(f).append(",");

return bob.append(";").toString(); 
}



    public boolean equals(Object oo) {
        if (this == oo)
            return true;


        if (oo == null || (!this.getClass().isAssignableFrom(oo.getClass()) || !oo.getClass().getName().equals(this.getClass().getName())))
            return false;
        javax.megaco.message.descriptor.TimeStamp o = (javax.megaco.message.descriptor.TimeStamp) oo;
        if ((gc != null && o.gc == null) || (gc == null && o.gc != null))
            return false;
        if (gc != null && o.gc != null)
            if (gc != null && o.gc != null && !gc.equals(o.gc))
                return false;

        return true;
    }
}




