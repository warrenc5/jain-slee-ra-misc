package javax.megaco.pkg.ext.AASDigitCollectionPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//The maximum amount of time to play and possibly replay an announcement or 
@Generated({"warren crossing"})
public class InapPromptTimerParam extends PkgItemParam {
	public static final int INAPPROMPTTIMER = 0x0017;
	public static final String TOKEN = "ipt";

	protected int[] paramsItemIds = null;

	public InapPromptTimerParam() {
		super();
		super.paramId = INAPPROMPTTIMER; //ipt
		super.itemValueType = ParamValueType.M_STRING; //M_STRING
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AASDigitCollectionPkg.PACKAGE_INSTANCE;
 //0x0034		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

