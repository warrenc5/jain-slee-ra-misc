package javax.megaco.message.descriptor;



class DescriptorUtils {

	static void checkMethodExtensionRules(String s) throws IllegalArgumentException {
		// FIXME add checks
		return;
	}
	
	static void checkTimeStampRules(String s) throws IllegalArgumentException {
		// FIXME add checks
		return;
	}

	public static void checkSrvcChngProfileRules(String profile)  throws IllegalArgumentException{
		// TODO Auto-generated method stub
		
	}

	public static void checkParamNameRules(String name)  throws IllegalArgumentException {
		// TODO Auto-generated method stub
		
	}




public String toString() {
 StringBuilder bob = new StringBuilder();
bob.append("DescriptorUtils:");


return bob.append(";").toString(); 
}



}


