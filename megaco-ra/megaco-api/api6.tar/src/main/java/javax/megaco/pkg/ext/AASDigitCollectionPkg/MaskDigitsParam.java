package javax.megaco.pkg.ext.AASDigitCollectionPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Indicates whether the received digits may be stored in a log file by the MG. 
@Generated({"warren crossing"})
public class MaskDigitsParam extends PkgItemParam {
	public static final int MASK_DIGITS = 0x001c;
	public static final String TOKEN = "mkdt";

	protected int[] paramsItemIds = null;

	public MaskDigitsParam() {
		super();
		super.paramId = MASK_DIGITS; //mkdt
		super.itemValueType = ParamValueType.M_BOOLEAN; //M_BOOLEAN
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AASDigitCollectionPkg.PACKAGE_INSTANCE;
 //0x0034		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

