package javax.megaco.pkg.ext.AASDigitCollectionPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//The number of attempts the MG made to collect a valid digit pattern. 
@Generated({"warren crossing"})
public class NumberOfAttemptsParam extends PkgItemParam {
	public static final int NUMBER_OF_ATTEMPTS = 0x0002;
	public static final String TOKEN = "na";

	protected int[] paramsItemIds = null;

	public NumberOfAttemptsParam() {
		super();
		super.paramId = NUMBER_OF_ATTEMPTS; //na
		super.itemValueType = ParamValueType.M_INTEGER; //M_INTEGER
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AASDigitCollectionPkg.PACKAGE_INSTANCE;
 //0x0034		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

