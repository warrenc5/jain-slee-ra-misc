package javax.megaco.pkg.ext.MultimediaRecordingPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Played after the user has failed to speak following a prompt. Consists of one or 
@Generated({"warren crossing"})
public class NoSpeechPromptParam extends PkgItemParam {
	public static final int NOSPEECHPROMPT = 0x0002;
	public static final String TOKEN = "ns";

	protected int[] paramsItemIds = null;

	public NoSpeechPromptParam() {
		super();
		super.paramId = NOSPEECHPROMPT; //ns
		super.itemValueType = ParamValueType.M_STRING; //M_STRING
		super.paramsDescriptorIds = new int[] {};
        super.packageId = MultimediaRecordingPkg.PACKAGE_INSTANCE;
 //0x00b3		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

