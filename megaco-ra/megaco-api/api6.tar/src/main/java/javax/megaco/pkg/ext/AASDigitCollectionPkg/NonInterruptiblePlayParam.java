package javax.megaco.pkg.ext.AASDigitCollectionPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Specifies whether or not prompts are interruptible by digit input. 
@Generated({"warren crossing"})
public class NonInterruptiblePlayParam extends PkgItemParam {
	public static final int NONINTERRUPTIBLEPLAY = 0x0006;
	public static final String TOKEN = "ni";

	protected int[] paramsItemIds = null;

	public NonInterruptiblePlayParam() {
		super();
		super.paramId = NONINTERRUPTIBLEPLAY; //ni
		super.itemValueType = ParamValueType.M_BOOLEAN; //M_BOOLEAN
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AASDigitCollectionPkg.PACKAGE_INSTANCE;
 //0x0034		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

