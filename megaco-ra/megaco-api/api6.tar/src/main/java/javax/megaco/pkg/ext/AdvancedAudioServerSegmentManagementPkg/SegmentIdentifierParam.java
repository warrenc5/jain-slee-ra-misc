package javax.megaco.pkg.ext.AdvancedAudioServerSegmentManagementPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Identifies the audio segment which is to be deleted. 
@Generated({"warren crossing"})
public class SegmentIdentifierParam extends PkgItemParam {
	public static final int SEGMENT_IDENTIFIER = 0x0001;
	public static final String TOKEN = "sid";

	protected int[] paramsItemIds = null;

	public SegmentIdentifierParam() {
		super();
		super.paramId = SEGMENT_IDENTIFIER; //sid
		super.itemValueType = ParamValueType.M_STRING; //M_STRING
		super.paramsDescriptorIds = new int[] {};
        super.packageId = AdvancedAudioServerSegmentManagementPkg.PACKAGE_INSTANCE;
 //0x0036		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

