package javax.megaco;

import java.io.Serializable;

/**
 * 
 * @author wozza
 */
public class ReturnStatus implements Serializable{

    /**
     * 
     */
    public static final int M_SUCCESS = 1;
    /**
     * 
     */
    public static final int M_FAILURE = 2;

    /**
     * 
     */
    public static final ReturnStatus SUCCESS = new ReturnStatus(M_SUCCESS);

    /**
     * 
     */
    public static final ReturnStatus FAILURE = new ReturnStatus(M_FAILURE);

	private int return_status;

	private ReturnStatus(int return_status) {
		this.return_status = return_status;

	}

    /**
     * 
     * @return
     */
    public int getReturnStatus() {
		return this.return_status;
	}

    /**
     * 
     * @param value
     * @return
     * @throws IllegalArgumentException
     */
    public static final ReturnStatus getObject(int value) throws IllegalArgumentException {
		ReturnStatus r = null;
		switch (value) {
		case M_SUCCESS:
			r = SUCCESS;
			break;

		case M_FAILURE:
			r = FAILURE;
			break;
		default:
			throw new IllegalArgumentException("No ReturnStatus for value " + value);

		}

		return r;
	}

	private Object readResolve() {

		return this.getObject(this.return_status);

	}

	@Override


public String toString() {
 StringBuilder bob = new StringBuilder();
bob.append("ReturnStatus:");

bob.append("return_status=").append(return_status).append(",");

return bob.toString(); 
}


}


