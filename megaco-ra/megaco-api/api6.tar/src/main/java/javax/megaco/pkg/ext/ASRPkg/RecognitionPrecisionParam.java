package javax.megaco.pkg.ext.ASRPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Depending on the implementation and capability of the recognizer resource it 
@Generated({"warren crossing"})
public class RecognitionPrecisionParam extends PkgItemParam {
	public static final int RECOGNITION_PRECISION = 0x0009;
	public static final String TOKEN = "ra";

	protected int[] paramsItemIds = null;

	public RecognitionPrecisionParam() {
		super();
		super.paramId = RECOGNITION_PRECISION; //ra
		super.itemValueType = ParamValueType.M_INTEGER; //M_INTEGER
		super.paramsDescriptorIds = new int[] {};
        super.packageId = ASRPkg.PACKAGE_INSTANCE;
 //0x00a6		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

