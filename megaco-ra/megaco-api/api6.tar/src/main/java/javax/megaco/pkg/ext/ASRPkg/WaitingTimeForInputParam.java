package javax.megaco.pkg.ext.ASRPkg;

import javax.megaco.message.DescriptorType;
import javax.megaco.pkg.ParamValueType;
import javax.megaco.pkg.PkgConsts;
import javax.megaco.pkg.PkgItemParam;
import javax.annotation.Generated;

//Defines the time to wait to detect user input, specified in units of 
@Generated({"warren crossing"})
public class WaitingTimeForInputParam extends PkgItemParam {
	public static final int WAITING_TIME_FOR_INPUT = 0x0008;
	public static final String TOKEN = "wit";

	protected int[] paramsItemIds = null;

	public WaitingTimeForInputParam() {
		super();
		super.paramId = WAITING_TIME_FOR_INPUT; //wit
		super.itemValueType = ParamValueType.M_INTEGER; //M_INTEGER
		super.paramsDescriptorIds = new int[] {};
        super.packageId = ASRPkg.PACKAGE_INSTANCE;
 //0x00a6		this.paramsItemIds = new int[] {}; 
	}

	public int getParamId() {

		return super.paramId;
	}

	public int getParamValueType() {

		return super.itemValueType;
	}

	public int[] getParamsItemIds() {
		return this.paramsItemIds;
	}

	public int[] getParamsDescriptorIds() {
		return super.paramsDescriptorIds;
	}
}

